<?php

session_start();

$uname = $_POST['uname'];
$password = $_POST['psw'];

if ($password == "bar") {
    $_SESSION['uname'] = $user;
    header("Location: index.php");
} else {
    header("Location: signin.php");
}